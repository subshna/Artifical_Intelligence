import boto3
from contextlib import closing
import time

giventext = 'The sun does arise and make happy the skies. The merry bells ring to welcome the spring'
# Convert text to mp3 using amazon polly.
PollyClnt = boto3.client(service_name='polly', region_name='us-east-2')
PollyResp = PollyClnt.synthesize_speech(
    OutputFormat = 'mp3',
    Text = giventext,
    TextType = 'text',
    VoiceId = 'Matthew'
)
print (PollyResp)

if 'AudioStream' in PollyResp:
    with closing(PollyResp['AudioStream']) as stream:
        output = 'Merry_Bells.mp3'
        try:
            flopen = open(output, 'wb')
            flopen.write(stream.read())
            print('%s file created successfully' % output)
            flopen.close()
        except IOError as error:
            print (error)

# Convert mp3 file to text and validate the same
timestamp = int(time.time())
transcribe = boto3.client(service_name='transcribe', region_name='us-east-2')
job_name = 'S2T'+str(timestamp)
job_uri = 'https://s3.us-east-2.amazonaws.com/aws07082018/Merry_Bells.mp3'
transcribe.start_transcription_job(
    TranscriptionJobName = job_name,
    Media = {'MediaFileUri': job_uri},
    MediaFormat = 'mp3',
    LanguageCode = 'en-US'
)
jobstatus = 'IN_PROGRESS'
while jobstatus == 'IN_PROGRESS':
    job = transcribe.get_transcription_job(TranscriptionJobName = job_name)
    jobstatus = job['TranscriptionJob']['TranscriptionJobStatus']
    time.sleep(5)

if jobstatus == 'FAILED':
    print('Job Failed')
elif jobstatus == 'COMPLETED':
    print('Uri {0}'.format(job['TranscriptionJob']['Transcript']['TranscriptFileUri']))